﻿namespace PetFinderMVC1.Models
{
    public class Publicacion
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public string Foto { get; set; }
        public string Descripcion { get; set; }
        public string Raza { get; set; }
        public string Especie { get; set; }
        public string Color { get; set; }
        public string Tamano { get; set; }
        public string Sexo { get; set; }
        public string UbicacionId { get; set; }
    }

}
